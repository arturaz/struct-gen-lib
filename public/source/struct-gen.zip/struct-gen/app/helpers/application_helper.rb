# Methods added to this helper will be available to all templates in the application.
module ApplicationHelper
  def progress_meter(message="Kraunama...")
    image_tag("progress.gif", :alt => message) + " #{message}"
  end
  
  def form_remote_tag_super(options={})
    options[:ajax_errors] = "ajax_errors" if options[:ajax_errors].nil?
    if options[:ajax_errors]    
      options[:loading] ||= ""
      options[:loading] += ";$('#{options[:ajax_errors]}').innerHTML='';"
      
      options[:url] ||= {}
      options[:url][:ajax_errors] = true
    end
    
    options[:progress] = "progress" if options[:progress].nil?
    if options[:progress]
      
      options[:loading] ||= ""
      options[:loading] += ";$('#{options[:progress]}').innerHTML='" +
        progress_meter + "';"
      
      options[:complete] ||= ""
      options[:complete] += ";$('#{options[:progress]}').innerHTML='';"
    end   
    
    form_remote_tag(options)
  end
end
