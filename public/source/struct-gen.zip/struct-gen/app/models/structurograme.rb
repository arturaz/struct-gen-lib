class Structurograme
  
  
  class Error < Exception
    attr_reader :errors
    
    def initialize(errors=[])
      errors = [errors] if not errors.kind_of? Array
      @errors = errors
      super()
    end
  end
  
  def self.create(params={}, basedir="#{RAILS_ROOT}/tmp/xml")
    self.validate_params(params)
    
    require 'xml/libxml'
    require 'pathname'
    @fname = "#{Time.new.to_i}-#{(rand*1000).round.to_s}"
    basepath = "#{basedir}/#{@fname}"        
    @xml = Pathname.new("#{basepath}.xml")
    @png = Pathname.new("#{basepath}.png")
    font = Pathname.new("#{RAILS_ROOT}/structurograme/cour.ttf")
    
    if %r{^(<\?xml.*?\?>)?\s*<(s|struct|structurograme)>.*?</\2>\s*$}m.match(
      params[:xml]
    ).nil?
      params[:xml] = "<s>#{params[:xml]}</s>"
    end
    params[:xml].gsub!('\<', '&lt;')
    params[:xml].gsub!('\>', '&gt;')
    params[:xml].gsub!('\"', '&quot;')
    params[:xml].gsub!('&', '&amp;')
    
    begin
      f = File.new(@xml, 'w')
      f.write(params[:xml])
      f.close
      
      doc = XML::Document.file(@xml.realpath.to_s)
    rescue XML::Parser::ParseError
        File.delete(@xml)
        raise self::Error.new("XML nesusiparsino ;-(")
    end
    
    File.new(@png, 'w').close
    
    # Stupid backward method, mongrel/webrick segfaults if I try to render
    # when using Structurograme from controller
    ran = system("#{RAILS_ROOT}/structurograme/execute.rb " +
      "#{@xml.realpath.to_s} " +
      "#{@png.realpath.to_s} " +
      "#{font.realpath.to_s} #{params[:size].to_i} " +
      "#{params[:width].to_i} #{params[:padding].to_i}")
    File.delete(@xml)
    if ran
      f = File.open(@png)
      png = f.read
      f.close
      File.delete(@png)
      return png
    else
      File.delete(@png)
      raise self::Error.new(
        "Klaida keistuolė (prašyk admino, kad žiūrėtų log'ą)")
    end  
  end
  
  def self.validate_params(params={})
    errors = []
    
    params[:size] ||= 12
    params[:width] ||= 800
    params[:padding] ||= 10
    
    if params[:xml].blank? or params[:xml].strip.empty?
      errors.push "Tuščias XML. Gal įrašytum ką nors?..." 
    end
    
    if params[:size].to_i <= 0
      errors.push "Padidink šriftą"
    end
    if params[:padding].to_i < 0
      errors.push "Neigiamas tarpų dydis"
    end
    if params[:width].to_i <= 0
      errors.push "Padidink paveiksliuko plotį"
    end
    
    raise self::Error.new(errors) if not errors.blank?
  end
end