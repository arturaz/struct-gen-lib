class StructurogrameApi < ActionWebService::API::Base
  api_method :generate_from_xml,
    :expects => [
      {:xml => :string},
      {:size => :int},
      {:width => :int},
      {:padding => :int}
    ],
    :returns => [:base64]
end
