# Filters added to this controller will be run for all controllers in the application.
# Likewise, all the methods added will be available for all controllers.
class ApplicationController < ActionController::Base
  private
  
  def ajax_errors(errors=[])
    str = ""
    if not errors.blank?
      str += "<h2>Klaidos!</h2><ul>"
      
      errors.each do |error|
        str += "<li>#{error}</li>"
      end
      
      str += "</ul>"
    end
    
    render :update do |page|
      page.replace_html("ajax_info", str)      
      # Red highlight
      page.visual_effect(:highlight, 'ajax_info', :startcolor => "'#d71e26'")
    end
  end
end