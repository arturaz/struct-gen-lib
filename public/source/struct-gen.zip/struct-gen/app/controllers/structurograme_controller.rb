class StructurogrameController < ApplicationController
  wsdl_service_name 'Structurograme'
  web_service_scaffold :invoke

  def generate_from_xml(xml="", size=nil, width=nil, padding=nil)
    begin
      Structurograme.create({
        :xml => xml,
        :size => size,
        :width => width,
        :padding => padding
      })
    rescue Structurograme::Error => err
      "Structurograme::Error|" + err.errors.join("|")
    end
  end
end
