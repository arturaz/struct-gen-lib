class IndexController < ApplicationController

  def index
  end
  
  def submit_xml
    begin
      session[:png] = Structurograme.create(params)
    rescue Structurograme::Error => error
      ajax_errors(error.errors)
      return
    end
  end
  
  def get_structurograme
    if not session[:png]
      render :text => "Nerasta"
    else      
      headers["Content-Type"] = "image/png"
      render :text => session[:png]
      session[:png] = nil
    end
  end
end
